﻿Imports System.Data.OleDb

Public Class refundfrm
    Private Sub Btnreturn_Click(sender As Object, e As EventArgs) Handles Btnreturn.Click
        frmPOS.Show()
        Me.Hide()

    End Sub

    Private Sub LoadProducts(Optional ByVal productCode As String = "", Optional ByVal transNo As String = "")
        Try
            Dim sql As String = "SELECT * FROM tblTransactionDetails WHERE 1 = 1"
            cmd = New OleDbCommand(sql, cn)
            dr = cmd.ExecuteReader

            ListView2.Items.Clear()
            Do While dr.Read = True
                Dim x As New ListViewItem(dr("TransNo").ToString)
                x.SubItems.Add(dr("ProductCode").ToString)
                x.SubItems.Add(dr("Amount").ToString)
                x.SubItems.Add(dr("Qty").ToString)
                x.SubItems.Add(dr("Total").ToString)
                ListView2.Items.Add(x)
            Loop
        Finally

            If dr IsNot Nothing Then
                dr.Close()
            End If
        End Try
    End Sub

    Private Sub TransferItemToRefund(item As ListViewItem)
        Try

            Dim returnQty As Integer = InputBox("Enter the quantity to return:", "Return Quantity", 1)


            If returnQty <= 0 OrElse returnQty > Convert.ToInt32(item.SubItems(3).Text) Then
                MessageBox.Show("Invalid return quantity.")
                Exit Sub
            End If

            Try
                cn.Open()

                Using cmd As New OleDbCommand("INSERT INTO tblReturned (TransNo, ProductCode, Amount, Qty, Total) VALUES (@TransNo, @Product, @Amount, @Qty, @Total)", cn)
                    cmd.Parameters.AddWithValue("TransNo", item.SubItems(0).Text)
                    cmd.Parameters.AddWithValue("ProductCode", item.SubItems(1).Text)
                    cmd.Parameters.AddWithValue("Amount", item.SubItems(2).Text)
                    cmd.Parameters.AddWithValue("Qty", returnQty)
                    cmd.Parameters.AddWithValue("Total", Convert.ToDecimal(item.SubItems(2).Text) * returnQty)
                    cmd.ExecuteNonQuery()
                End Using


                Dim remainingQty As Integer = Convert.ToInt32(item.SubItems(3).Text) - returnQty
                If remainingQty > 0 Then
                    Using cmd As New OleDbCommand("UPDATE tblTransactionDetails SET Qty = ?, Total = ? WHERE TransNo = ? AND ProductCode = ?", cn)
                        cmd.Parameters.AddWithValue("?", remainingQty)
                        cmd.Parameters.AddWithValue("?", Convert.ToDecimal(item.SubItems(2).Text) * remainingQty)
                        cmd.Parameters.AddWithValue("?", item.SubItems(0).Text)
                        cmd.Parameters.AddWithValue("?", item.SubItems(1).Text)
                        cmd.ExecuteNonQuery()
                    End Using
                Else
                    Using cmd As New OleDbCommand("DELETE FROM tblTransactionDetails WHERE TransNo = ? AND ProductCode = ?", cn)
                        cmd.Parameters.AddWithValue("?", item.SubItems(0).Text)
                        cmd.Parameters.AddWithValue("?", item.SubItems(1).Text)
                        cmd.ExecuteNonQuery()
                    End Using
                End If

                ' Reload sold items
                LoadProducts()
            Catch ex As Exception
                MessageBox.Show("Error processing refund: " & ex.Message)
            Finally

                If cn.State = ConnectionState.Open Then
                    cn.Close()
                End If
            End Try

        Catch ex As Exception

            If cn.State = ConnectionState.Closed Then
                MessageBox.Show("Connection was closed unexpectedly. Retrying...")
                Try
                    cn.Open()
                    Me.TransferItemToRefund(item)
                Catch ex2 As Exception
                    MessageBox.Show("Error reconnecting to database: " & ex2.Message)
                End Try
            Else
                MessageBox.Show("Error processing refund: " & ex.Message)
            End If
        Finally

            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub


    Private Sub btnrefund_Click(sender As Object, e As EventArgs) Handles btnrefund.Click
        If ListView2.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = ListView2.SelectedItems(0)
            TransferItemToRefund(selectedItem)
        Else
            MessageBox.Show("Please select an item to refund.")
        End If
    End Sub



    Private Sub ListView2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView2.SelectedIndexChanged
        If ListView2.SelectedItems.Count > 0 Then
            txtTransNum.Text = ListView2.SelectedItems(0).SubItems(0).Text
        End If
    End Sub

    Private Sub refundfrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        LoadProducts()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        returnsfrm.ShowDialog()
        Me.Hide()
    End Sub
End Class