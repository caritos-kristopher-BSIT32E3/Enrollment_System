﻿Imports System.Data.OleDb

Public Class frmPOS
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        dashboard.Show()
        Me.Hide()

    End Sub

    Private Sub frmPOS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call getTransactionNo()
        GenerateRandomRefNumber()
        LoadItems()

    End Sub

    Private Sub UP_Click(sender As Object, e As EventArgs) Handles UP.Click
        Call getTransactionNo()
        GenerateRandomRefNumber()
        LoadItems()

    End Sub


    Private Sub GenerateRandomRefNumber()
        Dim randomNumber As Integer = CInt(Rnd() * 1000000)
        Dim formattedNumber As String = randomNumber.ToString("000000")


        Dim refNumber As String = "REF-" & formattedNumber

        lblreferencenumber.Text = refNumber
    End Sub

    Private Sub getTransactionNo()
        Sql = "Select TransNo from tblTransactions order by TransNo desc"
        cmd = New OleDbCommand(Sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            lblTransNum.Text = Val(dr(0)) + 1
        Else
            lblTransNum.Text = 1000001
        End If
    End Sub

    Private Sub clearText()
        txtcode.Clear()
        amounttxt.Clear()
        txtcriticallevel.Clear()
        productnametxt.Clear()
        quantitytxt.Clear()
        statustxt.Text = "*****"
    End Sub

    Dim l As ListViewItem
    Dim amount As Double
    Private Sub btnaddtocart_Click(sender As Object, e As EventArgs) Handles btnaddtocart.Click
        Dim a As String = InputBox("Enter number of products?", "Quantity")
        If productnametxt.Text = "" Or txtcode.Text = "" Or quantitytxt.Text = "" Or amounttxt.Text = "" Then
            MsgBox("Please Complete the details", MsgBoxStyle.Exclamation)
        Else
        End If
        If a = "" Or a = 0 Then
            MsgBox("Please enter number of products")
        Else
            If Val(a) > Val(quantitytxt.Text) Then
                MsgBox("Number of products is greater than the available products", MsgBoxStyle.Exclamation, "Re-enter number of products")
            Else
                quantitytxt.Text = Val(quantitytxt.Text) - Val(a)
                amount = Val(amounttxt.Text) * Val(a)
                l = Me.ListView2.Items.Add(txtcode.Text)
                l.SubItems.Add(productnametxt.Text)
                l.SubItems.Add(amounttxt.Text)
                l.SubItems.Add(a)
                l.SubItems.Add(amount)
                If Val(quantitytxt.Text) = 0 Then
                    statustxt.Text = "OUT OF STOCK"
                ElseIf Val(quantitytxt.Text) <= Val(txtcriticallevel.Text) Then
                    statustxt.Text = "CRITICAL LEVEL"
                End If

            End If

        End If
        GetTotal()
        GetTotalItem()
        getVAT()
    End Sub

    Private Sub GetTotal()
        Dim totalAmount As Double = 0

        For i As Integer = 0 To ListView2.Items.Count - 1
            Dim price As Double
            Dim quantity As Integer

            If Double.TryParse(ListView2.Items(i).SubItems(2).Text, price) AndAlso Integer.TryParse(ListView2.Items(i).SubItems(3).Text, quantity) Then
                totalAmount += price * quantity
            Else
                Debug.Print("Invalid price or quantity format for item: " & i)
            End If
        Next

        lblTotal.Text = Format(totalAmount, "0.00")
    End Sub

    Private Sub GetTotalItem()
        Dim totalItems As Integer = 0

        For i As Integer = 0 To ListView2.Items.Count - 1
            Dim quantity As Integer

            If Integer.TryParse(ListView2.Items(i).SubItems(3).Text, quantity) Then
                totalItems += quantity
            Else
                Debug.Print("Invalid quantity format for item: " & i)
            End If
        Next

        lbltotalitems.Text = totalItems.ToString()
    End Sub



    Private Sub btnpayment_Click(sender As Object, e As EventArgs) Handles btnpayment.Click
        paymenstfrm.Show()
        paymenstfrm.lblGrandTotal.Text = Me.lblTotal.Text
    End Sub
    Private Sub getVAT()
        Dim vatableSales As Double
        vatableSales = Val(lblTotal.Text) / 1.12
        lblvatamount.Text = Format(Val(vatableSales), "0.00")
        lblvatavlesales.Text = Val(lblTotal.Text) - Val(lblvatamount.Text)
    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click

        If MsgBox("Save Transaction?", vbQuestion + vbYesNo) = vbYes Then

            If Val(lblamountpaid.Text) < Val(lblTotal.Text) Then
                MsgBox("Insufficient Amount Paid", MsgBoxStyle.Critical, "Please Re-Enter Payment")
                Exit Sub
            End If



            Sql = "Insert into tblTransactions(TransNo,TransDate,TransTime,TotalAmount,Change,VAT,VatableSales)values(@TransNo,@TransDate,@TransTime,@TotalAmount,@Change,@VAT,@VatableSales)"
            cmd = New OleDbCommand(Sql, cn)
            With cmd
                .Parameters.AddWithValue("@TransNo", lblTransNum.Text)
                .Parameters.AddWithValue("@TransDate", datelbl.Text)
                .Parameters.AddWithValue("@TransTime", timelbl.Text)
                .Parameters.AddWithValue("@TotalAmount", lblTotal.Text)
                .Parameters.AddWithValue("@Change", lblamountchange.Text)
                .Parameters.AddWithValue("@VAT", lblvatamount.Text)
                .Parameters.AddWithValue("@VatableSales", lblvatavlesales.Text)

                .ExecuteNonQuery()
            End With



            For Each i As ListViewItem In ListView2.Items
                Try

                    cmd.Parameters.AddWithValue("@TransNo", lblTransNum.Text)
                    cmd.Parameters.AddWithValue("@ProductCode", i.Text)
                    If Not i.SubItems(2).Text Is Nothing AndAlso Not String.IsNullOrEmpty(i.SubItems(2).Text) Then
                        cmd.Parameters.AddWithValue("@Amount", i.SubItems(2).Text)
                    Else
                        Throw New Exception("Amount subitem is missing or empty for item " & i.Text)
                    End If


                    cmd.ExecuteNonQuery()
                Catch ex As Exception
                    MsgBox("Error saving" & i.Text & ": " & ex.Message, MsgBoxStyle.Critical)

                End Try
            Next



            Sql = "Insert into tblPayments(TransNo,TotalAmount,AmountPaid,AmountChange,MOP,RefNo)Values(@TransNo,@TotalAmount,@AmountPaid,@AmountChange,@MOP,@RefNo)"
            cmd = New OleDbCommand(Sql, cn)
            cmd.Parameters.AddWithValue("@TransNo", lblTransNum.Text)
            cmd.Parameters.AddWithValue("@TotalAmount", lblTotal.Text)
            cmd.Parameters.AddWithValue("@AmountPaid", lblamountpaid.Text)
            cmd.Parameters.AddWithValue("@AmountChange", lblamountchange.Text)
            cmd.Parameters.AddWithValue("@MOP", lblmodepayment.Text)
            cmd.Parameters.AddWithValue("@RefNo", lblreferencenumber.Text)
            cmd.ExecuteNonQuery()

            MsgBox("Transaction Successfully Saved", MsgBoxStyle.Information)
            ListView2.Items.Clear()
            Call reset()

        End If


        Sql = "update tblProducts set Quantity=@Quantity where ProductCode=@ProductCode"
        cmd = New OleDbCommand(Sql, cn)
        With cmd
            .Parameters.AddWithValue("@Quantity", quantitytxt.Text)
            .Parameters.AddWithValue("@ProductCode", txtcode.Text)
            .ExecuteNonQuery()
        End With

        Call getTransactionNo()

    End Sub
    Private Sub reset()
        lblamountpaid.Text = "0.00"
        lblvatamount.Text = "0.00"
        lblvatavlesales.Text = "0.00"
        lbltotalitems.Text = "0.00"
        lblmodepayment.Text = "******"
        lblreferencenumber.Text = "*****"
        lblTotal.Text = "0.00"
        lblamountchange.Text = "0.00"
    End Sub




    Private Sub txtcode_TextChanged_1(sender As Object, e As EventArgs) Handles txtcode.TextChanged
        Sql = "Select prodName,Amount,Quantity,CriticalLevel,Status from qryProducts where productCode= '" & txtcode.Text & "' and Quantity> '0'"
        cmd = New OleDbCommand(Sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            productnametxt.Text = dr(0)
            amounttxt.Text = dr(1)
            quantitytxt.Text = dr(2)
            txtcriticallevel.Text = dr(3)
            statustxt.Text = dr(4)
        Else
            MsgBox("out of Stocked", MsgBoxStyle.Critical)
            clearText()
        End If
    End Sub
    Private Sub LoadItems()
        Sql = "SELECT * FROM tblProducts"
        cmd = New OleDbCommand(Sql, cn)
        dr = cmd.ExecuteReader

        ListView2.Items.Clear()
        Do While dr.Read()
            Dim x As New ListViewItem(dr("ProductCode").ToString)
            x.SubItems.Add(dr("ProdName").ToString)
            x.SubItems.Add(dr("Category").ToString)
            ListView2.Items.Add(x)
        Loop


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TransactionFrm.ShowDialog()
    End Sub
    Private Sub LoadItems(Optional ByVal category As String = "")
        Dim sql As String
        If String.IsNullOrEmpty(category) Then
            sql = "SELECT * FROM tblProducts"
        Else
            sql = "SELECT * FROM tblProducts WHERE Category = @Category"
        End If

        cmd = New OleDbCommand(sql, cn)
        If Not String.IsNullOrEmpty(category) Then
            cmd.Parameters.AddWithValue("@Category", category)
        End If
        dr = cmd.ExecuteReader()

        ListView2.Items.Clear()
        Do While dr.Read()
            Dim x As New ListViewItem(dr("ProductCode").ToString)
            x.SubItems.Add(dr("ProdName").ToString)
            x.SubItems.Add(dr("ProdDescription").ToString)
            x.SubItems.Add(dr("Category").ToString)
            ListView2.Items.Add(x)
        Loop
        dr.Close()
    End Sub


    Private Sub btncancel_Click(sender As Object, e As EventArgs) Handles btncancel.Click

        Call ResetText()
        Call clearText()
        ListView2.Items.Clear()
        Call reset()
    End Sub

    Private Sub ListView2_ItemActivate(sender As Object, e As EventArgs) Handles ListView2.ItemActivate
        If ListView2.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = ListView2.SelectedItems(0)
            Dim productCode As String = selectedItem.SubItems(0).Text
            Dim prodName As String = selectedItem.SubItems(1).Text
            Dim prodDescription As String = selectedItem.SubItems(2).Text
            Dim category As String = selectedItem.SubItems(3).Text

        End If
    End Sub
    Private Sub ListView2_Click(sender As Object, e As EventArgs) Handles ListView2.Click
        If ListView2.SelectedItems.Count > 0 Then
            txtcode.Text = ListView2.SelectedItems(0).SubItems(0).Text
        End If
    End Sub





    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick
        datelbl.Text = Now.ToShortDateString
        timelbl.Text = Now.ToShortTimeString
    End Sub

    Private Sub lblTotal_Click(sender As Object, e As EventArgs) Handles lblTotal.Click

    End Sub

    Private Sub REFUNDbtn_Click(sender As Object, e As EventArgs) Handles REFUNDbtn.Click
        ReturnsFrm.Show()
    End Sub

    Private Sub ListView2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView2.SelectedIndexChanged

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class