﻿Imports System.Data.OleDb

Public Class paymenstfrm
    Private Sub loadMOP()
        Sql = "Select PaymentMode from tblPaymentMode where status='1'"
        cmd = New OleDbCommand(Sql, cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        cboMOP.DataSource = dt
        cboMOP.DisplayMember = "PaymentMode"
    End Sub

    Private Sub cboMOP_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMOP.SelectedIndexChanged
        If cboMOP.Text = "CASH" Then
            txtRefNo.ReadOnly = False
            txtAmountPaid.Clear()
            txtAmountPaid.Enabled = True
        Else
            txtRefNo.ReadOnly = False
            txtAmountPaid.Text = lblGrandTotal.Text
            txtChange.Text = "0.00"
            txtAmountPaid.Enabled = False
        End If
    End Sub

    Private Sub txtAmountPaid_TextChanged(sender As Object, e As EventArgs) Handles txtAmountPaid.TextChanged
        Dim change As Double
        change = Val(txtAmountPaid.Text) - Val(lblGrandTotal.Text)
        txtChange.Text = Format(Val(change), "0.00")
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim a As String = InputBox("Enter mode of payment")
        Sql = "Insert into tblPaymentMode(PaymentMode,Status)values(@PaymentMode,@Status)"
        cmd = New OleDbCommand(Sql, cn)
        With cmd
            .Parameters.AddWithValue("@PaymentMode", a)
            .Parameters.AddWithValue("@Status", "1")
            .ExecuteNonQuery()
        End With
    End Sub

    Private Sub btnEnterPayment_Click_1(sender As Object, e As EventArgs) Handles btnEnterpayment.Click
        If Val(txtAmountPaid.Text) < Val(lblGrandTotal.Text) Then
            MsgBox("Insufficient Payment", MsgBoxStyle.Critical)
        Else
            frmPOS.lblamountpaid.Text = Me.txtAmountPaid.Text
            frmPOS.lblamountchange.Text = Me.txtChange.Text
            frmPOS.lblmodepayment.Text = Me.cboMOP.Text
            frmPOS.lblreferencenumber.Text = Me.txtRefNo.Text
            Me.Close()
        End If
    End Sub

    Private Sub paymenstfrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadMOP()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Me.Close()

    End Sub
End Class