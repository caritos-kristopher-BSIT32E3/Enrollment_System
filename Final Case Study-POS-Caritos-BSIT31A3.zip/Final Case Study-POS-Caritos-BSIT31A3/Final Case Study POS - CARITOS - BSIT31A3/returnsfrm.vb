﻿Imports System.Data.OleDb
Imports System.Net.Http.Headers

Public Class returnsfrm
    Private Sub Btnreturn_Click(sender As Object, e As EventArgs) Handles Btnreturn.Click
        refundfrm.Show()
        Me.Hide()
    End Sub

    Private Sub LoadProducts()
        Sql = "SELECT * FROM tblReturned"
        cmd = New OleDbCommand(Sql, cn)
        dr = cmd.ExecuteReader

        ListView2.Items.Clear()
        Do While dr.Read()
            Dim x As New ListViewItem(dr("TransNo").ToString)
            x.SubItems.Add(dr("ProductCode").ToString)
            x.SubItems.Add(dr("Amount").ToString)
            x.SubItems.Add(dr("Qty").ToString)
            x.SubItems.Add(dr("Total").ToString)
            ListView2.Items.Add(x)
        Loop

    End Sub

    Private Sub returnsfrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        LoadProducts()

    End Sub
End Class