﻿Imports System.Data.OleDb

Public Class product
    Private Sub Btnreturn_Click(sender As Object, e As EventArgs) Handles Btnreturn.Click
        dashboard.Show()
        Me.Hide()

    End Sub

    Private Sub product_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Call Connection()
        Call getTransactionNo()
        LoadProducts()
    End Sub

    Private Sub getTransactionNo()
        Sql = "Select TransNo from tblStockTrans order by TransNo desc"
        cmd = New OleDbCommand(Sql, cn)
        dr = cmd.ExecuteReader

        If dr.Read = True Then
            lblTransNum.Text = Val(dr(0)) + 1
        Else

            lblTransNum.Text = generateRandomTransactionNumber()
        End If

        dr.Close()
    End Sub

    Private Function generateRandomTransactionNumber() As Integer

        Return New Random().Next(1000001, 9999999)
    End Function

    Private Sub btnupdate1_Click(sender As Object, e As EventArgs) Handles btnupdate1.Click
        clearText()
        Call getTransactionNo()

    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Call CheckItem()
    End Sub
    Private Sub txtcode_TextChanged_1(sender As Object, e As EventArgs) Handles txtcode.TextChanged
        sql = "Select ProdName,Category,Amount,Quantity,CriticalLevel,Status from QryProducts where productCode= '" & txtcode.Text & "'"
        cmd = New OleDbCommand(Sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            txtproductname.Text = dr(0)
            cbocategory.Text = dr(1)
            txtprice.Text = dr(2)
            txtquantity.Text = dr(3)
            txtcritical.Text = dr(4)
            cbostatus.Text = dr(5)

            clearText()
        End If
    End Sub
    Private Sub clearText()
        txtproductname.Clear()
        txtprice.Clear()
        txtquantity.Clear()
        txtcritical.Clear()

    End Sub
    Private Sub SaveData()
        sql = "Insert into QryInventory([TransNo],[TransDate],[TransTime],[ProductCode],[ProdName],[Category],[Amount],[Quantity],[CriticalLevel],[Status]) values ([@TransNo],[@TransDate],[@TransTime],[@ProductCode],[@ProdName],[@Category],[@Amount],[@Quantity],[@CriticalLevel],[@Status])"
        cmd = New OleDbCommand(Sql, cn)

        With cmd
            .Parameters.AddWithValue("@TransNo", lblTransNum.Text)
            .Parameters.AddWithValue("@TransDate", datelbl.Text)
            .Parameters.AddWithValue("@TransTime", timeLBL.Text)
            .Parameters.AddWithValue("@ProductCode", txtcode.Text)
            .Parameters.AddWithValue("@ProdName", txtproductname.Text)
            .Parameters.AddWithValue("@Category", cbocategory.Text.ToString())
            .Parameters.AddWithValue("@Amount", txtprice.Text)
            .Parameters.AddWithValue("@Quantity", txtquantity.Text)
            .Parameters.AddWithValue("@CriticalLevel", txtcritical.Text)
            .Parameters.AddWithValue("@Status", cbostatus.Text.ToString())
            .ExecuteNonQuery()

        End With
        MsgBox("Product Successfully Saved", MsgBoxStyle.Information, "Save Data")
        clearText()
    End Sub
    Private Sub LoadProducts()
        Sql = "SELECT * FROM tblProducts"
        cmd = New OleDbCommand(Sql, cn)
        dr = cmd.ExecuteReader

        ListView1.Items.Clear()
        Do While dr.Read()
            Dim x As New ListViewItem(dr("ProductCode").ToString)
            x.SubItems.Add(dr("ProdName").ToString)
            x.SubItems.Add(dr("Quantity").ToString)
            x.SubItems.Add(dr("Amount").ToString)
            x.SubItems.Add(dr("Category").ToString)
            ListView1.Items.Add(x)
        Loop

    End Sub
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        If ListView1.SelectedItems.Count > 0 Then
            txtcode.Text = ListView1.SelectedItems(0).SubItems(0).Text
        End If
    End Sub


    Private Sub CheckItem()
        Sql = "Select ProductCode from tblProducts where ProductCode='" & txtcode.Text & "'"
        cmd = New OleDbCommand(Sql, cn)
        dr = cmd.ExecuteReader

        If dr.HasRows = True Then
            MsgBox("Product Already Exists", MsgBoxStyle.Exclamation)
        ElseIf String.IsNullOrWhiteSpace(txtcode.Text) OrElse String.IsNullOrWhiteSpace(txtproductname.Text) _
   OrElse String.IsNullOrWhiteSpace(cbocategory.Text) OrElse String.IsNullOrWhiteSpace(txtprice.Text) OrElse String.IsNullOrWhiteSpace(txtquantity.Text) _
   OrElse String.IsNullOrWhiteSpace(txtcritical.Text) OrElse String.IsNullOrWhiteSpace(cbostatus.Text) Then

            MsgBox("All fields are required!", vbCritical, "Error")
            Return
        Else
            If MsgBox("Saved Successfully!", MsgBoxStyle.Information, "Updated Product Info Saved") Then
                SaveData()
            Else
                MsgBox("User not saved.", MsgBoxStyle.Information, "Operation Canceled")
            End If

        End If

    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        datelbl.Text = Now.ToShortDateString
        timelbl.Text = Now.ToShortTimeString
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        frmPOS.ShowDialog()
    End Sub
    Private Sub UpdateData()
        Sql = "Update QryInventory set ProdName=@ProdName, ProdDescription=@ProdDescription, Category=@Category, Amount=@Amount, Quantity=@Quantity, CriticalLevel=@CriticalLevel, Status=@Status, SupplierName=@SupplierName, SupplierContact=@SupplierContact  where ProductCode=@ProductCode"
        cmd = New OleDbCommand(Sql, cn)
        With cmd


            .Parameters.AddWithValue("@ProdName", txtproductname.Text)
            .Parameters.AddWithValue("@Category", cbocategory.Text)
            .Parameters.AddWithValue("@Amount", txtprice.Text)
            .Parameters.AddWithValue("@Quantity", txtquantity.Text)
            .Parameters.AddWithValue("@CriticalLevel", txtcritical.ToString)
            .Parameters.AddWithValue("@Status", cbostatus.Text)
            .Parameters.AddWithValue("@ProductCode", txtcode.Text)
            .ExecuteNonQuery()

        End With
        clearText()
        LoadProducts()

    End Sub


    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click

        Dim qt As String = txtquantity.Text
        Dim st As String = txtaddstock.Text
        Dim qtInt As Integer
        Dim stInt As Integer


        If Integer.TryParse(qt, qtInt) AndAlso Integer.TryParse(st, stInt) Then
            Dim add As Integer = qtInt + stInt

            Sql = "update tblProducts set Quantity=@Quantity where ProductCode=@ProductCode"
            cmd = New OleDbCommand(Sql, cn)
            With cmd
                .Parameters.AddWithValue("@Quantity", add)
                .Parameters.AddWithValue("@ProductCode", txtcode.Text)

                .ExecuteNonQuery()
            End With
            MsgBox("Product Successfully Save", MsgBoxStyle.Information, "Save Data")
        Else

        End If
        Call SaveData()
        Call LoadProducts()
        Call getTransactionNo()


    End Sub

    Private Sub btnupdate1_Click_1(sender As Object, e As EventArgs) Handles btnupdate1.Click
        If txtcode.Text <> txtcode.Text Then
            MsgBox("Enter Existing Code", MsgBoxStyle.Critical)
        ElseIf String.IsNullOrWhiteSpace(txtcode.Text) OrElse String.IsNullOrWhiteSpace(txtproductname.Text) _
                    OrElse String.IsNullOrWhiteSpace(cbocategory.Text) OrElse String.IsNullOrWhiteSpace(txtprice.Text) OrElse String.IsNullOrWhiteSpace(txtquantity.Text) _
        OrElse String.IsNullOrWhiteSpace(txtcritical.Text) OrElse String.IsNullOrWhiteSpace(cbostatus.Text) Then
            MsgBox("Missing fields are required!", vbCritical, "Error")
            Return
        Else
            If MsgBox("Are you sure you want to update product info?", vbQuestion + vbYesNo) = vbYes Then
                MsgBox("Saved Successfully!", MsgBoxStyle.Information, "Added Product on stocks")
                UpdateData()
            Else
                MsgBox("User not saved.", MsgBoxStyle.Information, "Error Adding products on file")
            End If

        End If
    End Sub


End Class