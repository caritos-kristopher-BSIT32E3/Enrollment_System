﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class returnsfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(returnsfrm))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Btnreturn = New System.Windows.Forms.Button()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.TransNo = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TransDate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TransTime = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TotalAmount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Change = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.VatableSales = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.VAT = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CashierName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Btnreturn)
        Me.Panel1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel1.Location = New System.Drawing.Point(-52, -5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(905, 74)
        Me.Panel1.TabIndex = 116
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Bernard MT Condensed", 30.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(211, 16)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(285, 47)
        Me.Label4.TabIndex = 97
        Me.Label4.Text = "RETURNED ITEMS"
        '
        'Btnreturn
        '
        Me.Btnreturn.BackColor = System.Drawing.Color.Silver
        Me.Btnreturn.ForeColor = System.Drawing.Color.White
        Me.Btnreturn.Image = CType(resources.GetObject("Btnreturn.Image"), System.Drawing.Image)
        Me.Btnreturn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnreturn.Location = New System.Drawing.Point(63, 16)
        Me.Btnreturn.Margin = New System.Windows.Forms.Padding(2)
        Me.Btnreturn.Name = "Btnreturn"
        Me.Btnreturn.Size = New System.Drawing.Size(43, 42)
        Me.Btnreturn.TabIndex = 96
        Me.Btnreturn.Text = "   "
        Me.Btnreturn.UseVisualStyleBackColor = False
        '
        'ListView2
        '
        Me.ListView2.BackColor = System.Drawing.Color.Silver
        Me.ListView2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.TransNo, Me.TransDate, Me.TransTime, Me.TotalAmount, Me.Change, Me.VatableSales, Me.VAT, Me.CashierName})
        Me.ListView2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView2.GridLines = True
        Me.ListView2.HideSelection = False
        Me.ListView2.Location = New System.Drawing.Point(27, 102)
        Me.ListView2.Margin = New System.Windows.Forms.Padding(2)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(539, 391)
        Me.ListView2.TabIndex = 117
        Me.ListView2.UseCompatibleStateImageBehavior = False
        Me.ListView2.View = System.Windows.Forms.View.Details
        '
        'TransNo
        '
        Me.TransNo.Text = "Trans Number"
        Me.TransNo.Width = 130
        '
        'TransDate
        '
        Me.TransDate.Text = "Date"
        Me.TransDate.Width = 130
        '
        'TransTime
        '
        Me.TransTime.Text = "Time"
        Me.TransTime.Width = 137
        '
        'TotalAmount
        '
        Me.TotalAmount.Text = "Total Amount"
        Me.TotalAmount.Width = 215
        '
        'Change
        '
        Me.Change.Text = "Change"
        Me.Change.Width = 166
        '
        'VatableSales
        '
        Me.VatableSales.Text = "Vatable Sales"
        Me.VatableSales.Width = 191
        '
        'VAT
        '
        Me.VAT.Text = "VAT"
        Me.VAT.Width = 180
        '
        'CashierName
        '
        Me.CashierName.Text = "Cashier"
        Me.CashierName.Width = 564
        '
        'returnsfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(591, 529)
        Me.Controls.Add(Me.ListView2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "returnsfrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "returnsfrm"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Btnreturn As Button
    Friend WithEvents ListView2 As ListView
    Friend WithEvents TransNo As ColumnHeader
    Friend WithEvents TransDate As ColumnHeader
    Friend WithEvents TransTime As ColumnHeader
    Friend WithEvents TotalAmount As ColumnHeader
    Friend WithEvents Change As ColumnHeader
    Friend WithEvents VatableSales As ColumnHeader
    Friend WithEvents VAT As ColumnHeader
    Friend WithEvents CashierName As ColumnHeader
End Class
