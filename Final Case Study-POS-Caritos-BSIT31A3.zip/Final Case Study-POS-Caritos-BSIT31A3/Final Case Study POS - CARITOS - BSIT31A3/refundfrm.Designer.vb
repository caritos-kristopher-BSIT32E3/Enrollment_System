﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class refundfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(refundfrm))
        Me.btnrefund = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Btnreturn = New System.Windows.Forms.Button()
        Me.txtTransNum = New System.Windows.Forms.TextBox()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.TransNo = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ProductCode = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Amount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Qty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Total = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnrefund
        '
        Me.btnrefund.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnrefund.Font = New System.Drawing.Font("Britannic Bold", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefund.ForeColor = System.Drawing.Color.White
        Me.btnrefund.Location = New System.Drawing.Point(233, 160)
        Me.btnrefund.Margin = New System.Windows.Forms.Padding(2)
        Me.btnrefund.Name = "btnrefund"
        Me.btnrefund.Size = New System.Drawing.Size(310, 37)
        Me.btnrefund.TabIndex = 117
        Me.btnrefund.Text = "R E F U N D"
        Me.btnrefund.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Bernard MT Condensed", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(296, 91)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(209, 22)
        Me.Label1.TabIndex = 116
        Me.Label1.Text = "T r a n s a c t i o n  N o."
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Btnreturn)
        Me.Panel1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel1.Location = New System.Drawing.Point(-69, -8)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(905, 82)
        Me.Panel1.TabIndex = 115
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.Location = New System.Drawing.Point(780, 6)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(78, 74)
        Me.Button1.TabIndex = 98
        Me.Button1.Text = "   "
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Bernard MT Condensed", 30.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(265, 19)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(431, 47)
        Me.Label4.TabIndex = 97
        Me.Label4.Text = "R E T U R N S  & R E F U N D"
        '
        'Btnreturn
        '
        Me.Btnreturn.BackColor = System.Drawing.Color.Silver
        Me.Btnreturn.ForeColor = System.Drawing.Color.White
        Me.Btnreturn.Image = CType(resources.GetObject("Btnreturn.Image"), System.Drawing.Image)
        Me.Btnreturn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnreturn.Location = New System.Drawing.Point(80, 19)
        Me.Btnreturn.Margin = New System.Windows.Forms.Padding(2)
        Me.Btnreturn.Name = "Btnreturn"
        Me.Btnreturn.Size = New System.Drawing.Size(43, 42)
        Me.Btnreturn.TabIndex = 96
        Me.Btnreturn.Text = "   "
        Me.Btnreturn.UseVisualStyleBackColor = False
        '
        'txtTransNum
        '
        Me.txtTransNum.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtTransNum.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTransNum.ForeColor = System.Drawing.Color.White
        Me.txtTransNum.Location = New System.Drawing.Point(233, 120)
        Me.txtTransNum.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTransNum.Multiline = True
        Me.txtTransNum.Name = "txtTransNum"
        Me.txtTransNum.Size = New System.Drawing.Size(310, 36)
        Me.txtTransNum.TabIndex = 114
        '
        'ListView2
        '
        Me.ListView2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ListView2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.TransNo, Me.ProductCode, Me.Amount, Me.Qty, Me.Total})
        Me.ListView2.Font = New System.Drawing.Font("Arial Rounded MT Bold", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView2.ForeColor = System.Drawing.Color.White
        Me.ListView2.GridLines = True
        Me.ListView2.HideSelection = False
        Me.ListView2.Location = New System.Drawing.Point(11, 214)
        Me.ListView2.Margin = New System.Windows.Forms.Padding(2)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(765, 225)
        Me.ListView2.TabIndex = 113
        Me.ListView2.UseCompatibleStateImageBehavior = False
        Me.ListView2.View = System.Windows.Forms.View.Details
        '
        'TransNo
        '
        Me.TransNo.Text = "Trans Number"
        Me.TransNo.Width = 163
        '
        'ProductCode
        '
        Me.ProductCode.Text = "Product Code"
        Me.ProductCode.Width = 144
        '
        'Amount
        '
        Me.Amount.Text = "Amount"
        Me.Amount.Width = 80
        '
        'Qty
        '
        Me.Qty.Text = "Qty"
        Me.Qty.Width = 215
        '
        'Total
        '
        Me.Total.Text = "Total"
        Me.Total.Width = 166
        '
        'refundfrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnrefund)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txtTransNum)
        Me.Controls.Add(Me.ListView2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "refundfrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "refundfrm"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnrefund As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Btnreturn As Button
    Friend WithEvents txtTransNum As TextBox
    Friend WithEvents ListView2 As ListView
    Friend WithEvents TransNo As ColumnHeader
    Friend WithEvents ProductCode As ColumnHeader
    Friend WithEvents Amount As ColumnHeader
    Friend WithEvents Qty As ColumnHeader
    Friend WithEvents Total As ColumnHeader
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
End Class
