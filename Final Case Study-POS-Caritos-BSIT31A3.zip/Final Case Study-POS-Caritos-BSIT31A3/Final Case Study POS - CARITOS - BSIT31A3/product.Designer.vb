﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class product
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(product))
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtaddstock = New System.Windows.Forms.TextBox()
        Me.cbostatus = New System.Windows.Forms.ComboBox()
        Me.Status = New System.Windows.Forms.Label()
        Me.txtcritical = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtproductname = New System.Windows.Forms.TextBox()
        Me.txtcode = New System.Windows.Forms.TextBox()
        Me.txtquantity = New System.Windows.Forms.TextBox()
        Me.txtprice = New System.Windows.Forms.TextBox()
        Me.cbocategory = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ProductCode = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ProdName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Quantity = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Amount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Category = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Btnreturn = New System.Windows.Forms.Button()
        Me.btnupdate1 = New System.Windows.Forms.Button()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblTransNum = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbl = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.timelbl = New System.Windows.Forms.Label()
        Me.datelbl = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(416, 141)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 18)
        Me.Label9.TabIndex = 74
        Me.Label9.Text = "Add Stocks"
        '
        'txtaddstock
        '
        Me.txtaddstock.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaddstock.Location = New System.Drawing.Point(501, 133)
        Me.txtaddstock.Margin = New System.Windows.Forms.Padding(2)
        Me.txtaddstock.Multiline = True
        Me.txtaddstock.Name = "txtaddstock"
        Me.txtaddstock.Size = New System.Drawing.Size(199, 26)
        Me.txtaddstock.TabIndex = 73
        '
        'cbostatus
        '
        Me.cbostatus.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbostatus.FormattingEnabled = True
        Me.cbostatus.Items.AddRange(New Object() {"Available", "Out of Stock "})
        Me.cbostatus.Location = New System.Drawing.Point(174, 144)
        Me.cbostatus.Margin = New System.Windows.Forms.Padding(2)
        Me.cbostatus.Name = "cbostatus"
        Me.cbostatus.Size = New System.Drawing.Size(199, 26)
        Me.cbostatus.TabIndex = 71
        '
        'Status
        '
        Me.Status.AutoSize = True
        Me.Status.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Status.Location = New System.Drawing.Point(61, 149)
        Me.Status.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(47, 18)
        Me.Status.TabIndex = 70
        Me.Status.Text = "Status"
        '
        'txtcritical
        '
        Me.txtcritical.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcritical.Location = New System.Drawing.Point(501, 88)
        Me.txtcritical.Margin = New System.Windows.Forms.Padding(2)
        Me.txtcritical.Name = "txtcritical"
        Me.txtcritical.Size = New System.Drawing.Size(199, 25)
        Me.txtcritical.TabIndex = 69
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(399, 95)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 18)
        Me.Label8.TabIndex = 68
        Me.Label8.Text = "Critical Level"
        '
        'txtproductname
        '
        Me.txtproductname.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtproductname.Location = New System.Drawing.Point(174, 58)
        Me.txtproductname.Margin = New System.Windows.Forms.Padding(2)
        Me.txtproductname.Name = "txtproductname"
        Me.txtproductname.Size = New System.Drawing.Size(199, 25)
        Me.txtproductname.TabIndex = 65
        '
        'txtcode
        '
        Me.txtcode.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcode.Location = New System.Drawing.Point(174, 24)
        Me.txtcode.Margin = New System.Windows.Forms.Padding(2)
        Me.txtcode.Name = "txtcode"
        Me.txtcode.Size = New System.Drawing.Size(199, 25)
        Me.txtcode.TabIndex = 64
        '
        'txtquantity
        '
        Me.txtquantity.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtquantity.Location = New System.Drawing.Point(501, 50)
        Me.txtquantity.Margin = New System.Windows.Forms.Padding(2)
        Me.txtquantity.Name = "txtquantity"
        Me.txtquantity.Size = New System.Drawing.Size(199, 25)
        Me.txtquantity.TabIndex = 63
        '
        'txtprice
        '
        Me.txtprice.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtprice.Location = New System.Drawing.Point(501, 14)
        Me.txtprice.Margin = New System.Windows.Forms.Padding(2)
        Me.txtprice.Name = "txtprice"
        Me.txtprice.Size = New System.Drawing.Size(199, 25)
        Me.txtprice.TabIndex = 62
        '
        'cbocategory
        '
        Me.cbocategory.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbocategory.FormattingEnabled = True
        Me.cbocategory.Items.AddRange(New Object() {"Beef 1 kilo", "Pork 1 kilo", "Chicken 1 kilo", "Nuggets 1 kilo", "Ham 1 kilo"})
        Me.cbocategory.Location = New System.Drawing.Point(174, 102)
        Me.cbocategory.Margin = New System.Windows.Forms.Padding(2)
        Me.cbocategory.Name = "cbocategory"
        Me.cbocategory.Size = New System.Drawing.Size(199, 26)
        Me.cbocategory.TabIndex = 61
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(67, 104)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 18)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "Category"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(399, 22)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 18)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "Price"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(399, 58)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 18)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "Quantity"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(67, 26)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 18)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "Product Code"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(67, 60)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 18)
        Me.Label1.TabIndex = 56
        Me.Label1.Text = "Product Name"
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.Color.Gray
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ProductCode, Me.ProdName, Me.Quantity, Me.Amount, Me.Category})
        Me.ListView1.Font = New System.Drawing.Font("Bernard MT Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView1.ForeColor = System.Drawing.Color.White
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(55, 226)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(938, 203)
        Me.ListView1.TabIndex = 79
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ProductCode
        '
        Me.ProductCode.DisplayIndex = 1
        Me.ProductCode.Text = "Barcode"
        Me.ProductCode.Width = 159
        '
        'ProdName
        '
        Me.ProdName.DisplayIndex = 0
        Me.ProdName.Text = "Product Name"
        Me.ProdName.Width = 211
        '
        'Quantity
        '
        Me.Quantity.Text = "Quantity"
        Me.Quantity.Width = 136
        '
        'Amount
        '
        Me.Amount.Text = "Price"
        Me.Amount.Width = 208
        '
        'Category
        '
        Me.Category.Text = "Category"
        Me.Category.Width = 337
        '
        'Btnreturn
        '
        Me.Btnreturn.BackColor = System.Drawing.Color.Silver
        Me.Btnreturn.ForeColor = System.Drawing.Color.White
        Me.Btnreturn.Image = CType(resources.GetObject("Btnreturn.Image"), System.Drawing.Image)
        Me.Btnreturn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnreturn.Location = New System.Drawing.Point(11, 15)
        Me.Btnreturn.Margin = New System.Windows.Forms.Padding(2)
        Me.Btnreturn.Name = "Btnreturn"
        Me.Btnreturn.Size = New System.Drawing.Size(43, 42)
        Me.Btnreturn.TabIndex = 97
        Me.Btnreturn.Text = "   "
        Me.Btnreturn.UseVisualStyleBackColor = False
        '
        'btnupdate1
        '
        Me.btnupdate1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnupdate1.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate1.ForeColor = System.Drawing.Color.White
        Me.btnupdate1.Location = New System.Drawing.Point(721, 49)
        Me.btnupdate1.Margin = New System.Windows.Forms.Padding(2)
        Me.btnupdate1.Name = "btnupdate1"
        Me.btnupdate1.Size = New System.Drawing.Size(202, 29)
        Me.btnupdate1.TabIndex = 100
        Me.btnupdate1.Text = "R E F R E S H "
        Me.btnupdate1.UseVisualStyleBackColor = False
        '
        'btnupdate
        '
        Me.btnupdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnupdate.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate.ForeColor = System.Drawing.Color.White
        Me.btnupdate.Location = New System.Drawing.Point(721, 90)
        Me.btnupdate.Margin = New System.Windows.Forms.Padding(2)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(202, 29)
        Me.btnupdate.TabIndex = 99
        Me.btnupdate.Text = "U P D A T E"
        Me.btnupdate.UseVisualStyleBackColor = False
        '
        'btnadd
        '
        Me.btnadd.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnadd.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.ForeColor = System.Drawing.Color.White
        Me.btnadd.Location = New System.Drawing.Point(721, 131)
        Me.btnadd.Margin = New System.Windows.Forms.Padding(2)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(202, 29)
        Me.btnadd.TabIndex = 98
        Me.btnadd.Text = "A D D"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Bernard MT Condensed", 30.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(56, 176)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(484, 47)
        Me.Label6.TabIndex = 101
        Me.Label6.Text = "M A N A G E    P R O D U C T S"
        '
        'lblTransNum
        '
        Me.lblTransNum.AutoSize = True
        Me.lblTransNum.BackColor = System.Drawing.Color.Transparent
        Me.lblTransNum.Font = New System.Drawing.Font("Britannic Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTransNum.ForeColor = System.Drawing.Color.Black
        Me.lblTransNum.Location = New System.Drawing.Point(895, 14)
        Me.lblTransNum.Name = "lblTransNum"
        Me.lblTransNum.Size = New System.Drawing.Size(28, 17)
        Me.lblTransNum.TabIndex = 126
        Me.lblTransNum.Text = "-----"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Britannic Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(793, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 17)
        Me.Label7.TabIndex = 125
        Me.Label7.Text = "NUMBER"
        '
        'lbl
        '
        Me.lbl.AutoSize = True
        Me.lbl.BackColor = System.Drawing.Color.Transparent
        Me.lbl.Font = New System.Drawing.Font("Britannic Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl.ForeColor = System.Drawing.Color.Black
        Me.lbl.Location = New System.Drawing.Point(718, 16)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(106, 17)
        Me.lbl.TabIndex = 124
        Me.lbl.Text = "TRANSACTION"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Bernard MT Condensed", 11.0!)
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(780, 162)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(34, 18)
        Me.Label22.TabIndex = 143
        Me.Label22.Text = "TIME"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Bernard MT Condensed", 11.0!)
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(780, 196)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(40, 18)
        Me.Label21.TabIndex = 142
        Me.Label21.Text = "DATE "
        '
        'timelbl
        '
        Me.timelbl.AutoSize = True
        Me.timelbl.Font = New System.Drawing.Font("Bernard MT Condensed", 11.0!)
        Me.timelbl.ForeColor = System.Drawing.Color.Black
        Me.timelbl.Location = New System.Drawing.Point(897, 162)
        Me.timelbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.timelbl.Name = "timelbl"
        Me.timelbl.Size = New System.Drawing.Size(56, 18)
        Me.timelbl.TabIndex = 141
        Me.timelbl.Text = "******"
        '
        'datelbl
        '
        Me.datelbl.AutoSize = True
        Me.datelbl.Font = New System.Drawing.Font("Bernard MT Condensed", 11.0!)
        Me.datelbl.ForeColor = System.Drawing.Color.Black
        Me.datelbl.Location = New System.Drawing.Point(897, 200)
        Me.datelbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.datelbl.Name = "datelbl"
        Me.datelbl.Size = New System.Drawing.Size(56, 18)
        Me.datelbl.TabIndex = 140
        Me.datelbl.Text = "******"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'product
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1005, 450)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.timelbl)
        Me.Controls.Add(Me.datelbl)
        Me.Controls.Add(Me.lblTransNum)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lbl)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnupdate1)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.Btnreturn)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtaddstock)
        Me.Controls.Add(Me.cbostatus)
        Me.Controls.Add(Me.Status)
        Me.Controls.Add(Me.txtcritical)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtproductname)
        Me.Controls.Add(Me.txtcode)
        Me.Controls.Add(Me.txtquantity)
        Me.Controls.Add(Me.txtprice)
        Me.Controls.Add(Me.cbocategory)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "product"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "product"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label9 As Label
    Friend WithEvents txtaddstock As TextBox
    Friend WithEvents cbostatus As ComboBox
    Friend WithEvents Status As Label
    Friend WithEvents txtcritical As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtproductname As TextBox
    Friend WithEvents txtcode As TextBox
    Friend WithEvents txtquantity As TextBox
    Friend WithEvents txtprice As TextBox
    Friend WithEvents cbocategory As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ListView1 As ListView
    Friend WithEvents ProdName As ColumnHeader
    Friend WithEvents ProductCode As ColumnHeader
    Friend WithEvents Quantity As ColumnHeader
    Friend WithEvents Amount As ColumnHeader
    Friend WithEvents Category As ColumnHeader
    Friend WithEvents Btnreturn As Button
    Friend WithEvents btnupdate1 As Button
    Friend WithEvents btnupdate As Button
    Friend WithEvents btnadd As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents lblTransNum As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lbl As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents timelbl As Label
    Friend WithEvents datelbl As Label
    Friend WithEvents Timer1 As Timer
End Class
