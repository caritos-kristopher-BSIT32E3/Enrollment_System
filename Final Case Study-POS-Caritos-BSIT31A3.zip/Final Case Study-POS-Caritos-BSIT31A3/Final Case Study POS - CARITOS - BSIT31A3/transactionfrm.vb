﻿Imports System.Data.OleDb

Public Class transactionfrm
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        returnsfrm.Show()
        Me.Hide()

    End Sub


    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        frmPOS.Show()
        Me.Hide()

    End Sub

    Private Sub transactionfrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call LoadProducts()
    End Sub
    Private Sub LoadProducts()

        Dim DATEFR As String = dtpStartDate.Value.ToString("yyyy-MM-dd")
        Dim DATETO As String = dtpEndDate.Value.ToString("yyyy-MM-dd")

        Sql = "SELECT * FROM tblTransactions WHERE TransDate >= @startDate AND TransDate <= @endDate"
        cmd = New OleDbCommand(Sql, cn)

        cmd.Parameters.AddWithValue("@startDate", DATEFR)
        cmd.Parameters.AddWithValue("@endDate", DATETO)

        dr = cmd.ExecuteReader

        ListView2.Items.Clear()
        Do While dr.Read()
            Dim x As New ListViewItem(dr("TransNo").ToString)
            x.SubItems.Add(dr("TransDate").ToString)
            x.SubItems.Add(dr("TransTime").ToString)
            x.SubItems.Add(dr("TotalAmount").ToString)
            x.SubItems.Add(dr("Change").ToString)
            x.SubItems.Add(dr("VAT").ToString)
            x.SubItems.Add(dr("VatableSales").ToString)

            ListView2.Items.Add(x)
        Loop
        Call GetTotal()
    End Sub
    Private Sub GetTotal()
        Const col As Integer = 3
        Dim total As Integer
        Dim listt As ListViewItem.ListViewSubItem
        For i As Integer = 0 To ListView2.Items.Count - 1
            listt = ListView2.Items(i).SubItems(col)
            total += Double.Parse(listt.Text)
        Next
        lblTotal.Text = Format(Val(total), "0.00")
    End Sub



    Private Sub ListView2_MouseClick(sender As Object, e As MouseEventArgs) Handles ListView2.MouseClick
        If ListView2.Items.Count > 0 Then
            Dim i As ListViewItem = ListView2.SelectedItems(0)
        End If

    End Sub



    Private Sub ItemtoRef(item As ListViewItem)
        Try
            cn.Open()
            Dim cm As New OleDbCommand("INSERT INTO tblReturned (TransNo, TransDate, TransTime, TotalAmount, Change, VAT, VatableSales, CashierName) VALUES (@TransNo, @TransDate, @TransTime, @TotalAmount, @Change, @VAT, @VatableSales, @CashierName)", cn)
            cm.Parameters.AddWithValue("TransNo", item.SubItems(0).Text)
            cm.Parameters.AddWithValue("TransDate", item.SubItems(1).Text)
            cm.Parameters.AddWithValue("TransTime", item.SubItems(2).Text)
            cm.Parameters.AddWithValue("TotalAmount", item.SubItems(3).Text)
            cm.Parameters.AddWithValue("Change", item.SubItems(4).Text)
            cm.Parameters.AddWithValue("VAT", item.SubItems(5).Text)
            cm.Parameters.AddWithValue("VatableSales", item.SubItems(6).Text)
            cm.Parameters.AddWithValue("CashierName", item.SubItems(7).Text)
            cm.ExecuteNonQuery()

            cm = New OleDbCommand("DELETE FROM tblTransactions WHERE TransNo = ?", cn)
            cm.Parameters.AddWithValue("?", item.SubItems(0).Text)
            cm.ExecuteNonQuery()

            LoadProducts()
        Catch ex As Exception
            MessageBox.Show("Select to Refund")
        Finally
            cn.Close()
        End Try
    End Sub

    Private Sub btnFilter_Click(sender As Object, e As EventArgs) Handles btnFilter.Click
        Call LoadProducts()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs)

    End Sub
End Class